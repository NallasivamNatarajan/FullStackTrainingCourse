﻿CREATE TABLE setList(
empId INT,
empName CHAR(20),
designation CHAR(10)
);


INSERT INTO setList VALUES(123,'someName','someDesig');
INSERT INTO setList VALUES(124,'someName1','someDesig1');
INSERT INTO setList VALUES(123,'someName','someDesig');

INSERT INTO setList(empId,empName) VALUES(123,'someName');
INSERT INTO setList(empId,designation) VALUES(123,'someDesig');
INSERT INTO setList(empId,designation) VALUES(1234,'someDesig');


DROP TABLE set33


ALTER TABLE setList RENAME TO set33

TRUNCATE TABLE setList

SELECT * FROM setList

RENAME setList to set33

ALTER TABLE setList ADD COLUMN salary DECIMAL(10,2)

ALTER TABLE setList DROP COLUMN salary DECIMAL(10,2)



ALTER TABLE setList DROP COLUMN empName

ALTER TABLE setList RENAME salary TO salaryPackage

ALTER TABLE setList DROP COLUMN salaryPackage


COMMIT;

ROLLBACK;



SELECT current_date as current_date

SELECT current_time 

SELECT current_timestamp



CREATE TABLE employee(
	empId INT ,
	empName CHAR(30),
	salary DECIMAL(10,2),
	deptId INT, 
	CONSTRAINT empId_Pk PRIMARY KEY(empId),
	CONSTRAINT deptId_fk FOREIGN KEY(deptId) REFERENCES dept(deptId)
);

CREATE TABLE dept(
	deptId INT PRIMARY KEY,
	deptName CHAR(20)
);

	CREATE TABLE trainingDept(
	trainingId INT,
	deptId INT CHECK(deptId=10),
	task CHAR(20),
	CONSTRAINT trainingId_pk PRIMARY KEY(trainingId),
	CONSTRAINT deptId_Fk FOREIGN KEY(deptId) REFERENCES dept(deptId)
);


create table test( id int, ProductName Char(20), available char(4) check(available='yes'));

insert into test values(1,'dddd','yes');
insert into test values(1,'dddd','NO');
select * from test
drop table test

CREATE TABLE student(	
	regNo INT UNIQUE,
	name CHAR(20),	
	deptNo INT);

SELECT * FROM student

INSERT INTO student VALUES(111,'ddfdfsa',10);
INSERT INTO student(name,deptNo) VALUES('SDFLDFJ',23);
drop table student

NOT NULL
CREATE TABLE student(	
	regNo INT UNIQUE,
	name CHAR(4),	
	deptNo INT NOT NULL
);

select * from student
INSERT INTO student VALUES(111,'Gopi',10);
INSERT INTO student VALUES(112,'RAJA',10);
INSERT INTO student VALUES(113,'Siva',10);
INSERT INTO student VALUES(114,'Ejas',10);
INSERT INTO student VALUES(115,'Mala',10);
INSERT INTO student VALUES(116,'Bala',10);
INSERT INTO student(name,deptNo) VALUES('SDFLDFJ',23);
INSERT INTO student(regNo,name) VALUES(123,'SDFLDFJ');

UPDATE student SET regNo=21 
WHERE deptNo=23

UPDATE student SET name='somename'
WHERE regNo=111

INSERT INTO student values(12,'name',32),(13,'name1',20),(16,'name2',42)


update student set name='newname',deptNo=50
where regNo=21

delete from student where deptNo=20
select * from student


INSERT INTO trainingDept VALUES(23,10,'Training Java')
INSERT INTO trainingDept VALUES(23,11,'Training Java')

select * from trainingdept

INSERT INTO dept(deptId,deptName) values(10,'Training');
INSERT INTO dept(deptId,deptName) values(11,'HR');
INSERT INTO dept(deptId,deptName) values(12,'Disaster Recovery');


SELECT * FROM dept


SELECT * FROM employee
truncate table employee

INSERT INTO employee(empId,empName,salary,deptId) values(123,'Gopi',1234,10);
INSERT INTO employee(empId,empName,salary,deptId) values(124,'Arjun',1234,11);
INSERT INTO employee(empId,empName,salary,deptId) values(125,'Raja',1234,12);
INSERT INTO employee(empId,empName,salary,deptId) values(126,'Gopal',12454,10);


select * from employee

SELECT empName FROM employee WHERE deptId=10
Select empName from employee where salary > 10000 AND Salary < 50000
Select empName from employee where deptId=10 OR deptId=12


select empName,deptId from employee
SELECT empName FROM employee LIMIT 1
SELECT name FROM student LIMIT 2

select empName,deptId from employee
where deptId=10
limit 5


insert into employee values(19,'dlfkj',12323,10),(16,'dlfkj',12323,10),(17,'dlfkj',12323,10),(18,'dlfkj',12323,10)


SELECT empName,deptId FROM  employee 
GROUP BY empName,deptId

select * from employee where deptId=10


SELECT empName,deptId FROM employee
ORDER BY deptId


SELECT empId, empName,deptId 
FROM employee
WHERE empName LIKE 'G%'


SELECT empId, empName,deptId 
FROM employee
WHERE empName LIKE 'G%i%'


SELECT empId, empName,deptId 
FROM employee
WHERE empName LIKE '_%l%'


SELECT empId, empName,deptId 
FROM employee
WHERE empName LIKE '_o%l%'
GROUP BY empId,empName
ORDER BY deptId


SELECT regNo, name 
FROM student
WHERE name LIKE '_%A'

