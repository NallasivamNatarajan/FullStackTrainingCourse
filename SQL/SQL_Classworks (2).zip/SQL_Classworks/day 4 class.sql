﻿with select_emp as (SELECT emp_id, emp_name 
			FROM employee)

select * from select_emp where emp_id='E01' 


WITH select_dept AS (SELECT dept_id from department)
SELECT emp_id,emp_name 
FROM employee
WHERE dept_id IN (select * from select_dept)



SELECT e.emp_id,e.emp_name,e.mgr_id 
FROM employee e
WHERE e.mgr_id IN (SELECT m.emp_id FROM employee m)


CREATE table customer(cust_id INT,cust_Name CHAR(20));
CREATE table customer_Copy(cust_id INT,cust_Name CHAR(20));

insert into customer values(123,'sedfsdf');
insert into customer values(124,'sedff');


SELECT * INTO customer_backup FROM customer
drop table customer_backup
select * from customer_backup



SELECT e.emp_id,e.emp_name,d.dept_id,d.dept_name 
FROM employee e
CROSS JOIN department d


SELECT e.emp_id,e.emp_name,d.dept_id,d.dept_name 
FROM employee e 
INNER JOIN department d
ON d.dept_id=e.dept_id



select a.project_id,count(a.emp_id) from allocation a 
inner join employee e
on a.emp_id=e.emp_id
group by a.project_id



select a.project_id,p.project_name,count(a.emp_id) 
from allocation a 
inner join employee e
on a.emp_id=e.emp_id
inner join t_project p
on a.project_id=p.project_id
group by a.project_id,p.project_name



--skill without employee

select s.skill_id,s.skill_name from skill s
left join employeeskill es
on s.skill_id = es.skill_id
where es.skill_id is null

select * from skill s left join employeeskill es on s.skill_id = es.skill_id




select e.emp_id,e.emp_name,e.mgr_id from employee e
where e.mgr_id=(select m.emp_id from employee m where m.emp_id=e.mgr_id)


SELECT * FROM skill s 
LEFT JOIN employeeskill es
ON s.skill_id=es.skill_id


select * from employeeskill where skill_id='S07'


SELECT e.emp_id,e.emp_name,a.project_id 
FROM employee e
LEFT JOIN allocation a
ON e.emp_id=a.emp_id



SELECT e.emp_id,e.emp_name,a.project_id 
FROM allocation a
RIGHT JOIN employee e
ON a.emp_id=e.emp_id


create table test1(test1_id int, name char(20))
create table test2(test2_id int, test1_id int, test2_name char(20))

select * from test1 t1 right join test2 t2  on t1.test1_id=t2.test1_id

select *from test1

select * from test2
insert into test1 values(12,'asdf');
insert into test1 values(13,'asd');
insert into test2 values(1,12,'asdf');
insert into test2 values(2,13,'asd');
insert into test2 values(3,14,'asdf');



SELECT e.emp_id,e.emp_name,e.emp_id as Manager_id
FROM employee e
WHERE e.mgr_id=(SELECT m.emp_id FROM employee m
		WHERE m.emp_id=e.mgr_id)


CREATE VIEW emp_count as (
	SELECT count(emp_Id) as Emp_count 
	from allocation 
	group by project_id)

select * from emp_count
drop view emp_count


CREATE TABLE autoincrement(Id serial,somename char(20));

INSERT INTO autoincrement(somename) VALUES('SDFDSDA');
INSERT INTO autoincrement(somename) VALUES('SDFA');
INSERT INTO autoincrement(somename) VALUES('SDFD');

SELECT * FROM autoincrement


create table liketest(name varchar(20));

insert into liketest values('asdf');
insert into liketest values('dfwf');
insert into liketest values('jkhgjh');
insert into liketest values('iwuertg');


select * FRoM liketest

select name from liketest where name like '_%f'

select * from test

CREATE OR REPLACE FUNCTION insert_test(Id Int,Name char)
RETURNS boolean AS $result$

DECLARE
	status boolean;
BEGIN
	status:=false;
	INSERT INTO test VALUES(Id,Name);
	status:=true;

RETURN status;
END;
$result$LANGUAGE PLPGSQL


SELECT <functionName>(parameters);
select * from test
SELECT insert_test(123,'tiger');



CREATE OR REPLACE FUNCTION insertliketest(name varchar) RETURNS boolean AS $status$
Declare
	status boolean;
Begin
	status:=false;
	INSERT INTO liketest values(name);
	status:=true;
return status;
End;
$status$ LANGUAGE PLPGSQL;

select insertliketest('Gopi');









































