﻿select * from skill

select * from employeeskill

select * from department

select * from allocation

select * from employee

select * from t_project

select * from role


CREATE TABLE testAlter(someId int, someName char(20));

select * from newTestAlter;
truncate table testAlter
INSERT INTO newtestAlter values(1,'dfdf');
INSERT INTO testAlter values(1,'dfdf');
INSERT INTO testAlter values(1,'dfdf');

ALTER TABLE testAlter ADD CONSTRAINT someId_pk PRIMARY KEY(someId);

ALTER TABLE testAlter DROP CONSTRAINT someId_pk


ALTER TABLE testAlter ALTER COLUMN someName TYPE CHAR(5);


ALTER TABLE testAlter RENAME TO newTestAlter



SELECT COUNT(emp_Id) FROM employee

select * from employee
select * from t_project

select * from allocation

SELECT project_id, count(emp_id) as emp_Count from allocation
group by project_Id

SELECT max(salary) from employee


SELECT UPPER(emp_Name) FROM employee
SELECT LOWER(emp_Name) FROM employee


SELECT SUM(salary) FROM employee



create user gopi with password '123'


grant all privileges on employee to gopi
revoke insert on employee from gopi




1. Which PROJECT has maximum number of EMPLOYEES?
select project_id,count(emp_id) from allocation
group by project_id
having count(emp_id)>= all(select count(emp_id) from allocation group by project_id)


7. What is the salary of employee, who played maximum roles in Project 'P07'?


select emp_id,project_id from allocation group by emp_id,project_id
having count(role_id)>=all (select count(role_id) from allocation where project_id='P01' group by role_id)

2. Which EMPLOYEE has not yet been allocated to any PROJECT?

select emp_id,emp_name from employee where emp_id  not in (select emp_id from allocation)


15. Find the total number of days worked by the employee 'E04' in project 'P02'?

select sum(to_date-from_date) from allocation where emp_id='E04' and Project_id='P02'


17.How many employees were working for the Project, which has crossed the deadline?

select project_id from allocation  where to_date in (select deadline from t_project)
group by project_id

(select pid from allocation where to_date>deadline)




where--->single columns or single value, single row functions
having ---> aggregate functions and 


having--->count(emp_id),SUM(),MIN(),MAX()

where---->upper(emp_id),tim(),lower() 



ALL  -->
EXISTS
BETWEEN 
NOT---> negative
NOT IN
IN  --> multiple row comparision
NOT EXISTS

Distinct


select distinct(somename) from newtestalter 


Select
from
where
group by
having
order by ASC, DESC



CREATE TABLE emp(id INT, name CHAR(20))

INSERT INTO emp VALUES(1,'java');
INSERT INTO emp VALUES(2,'java');
INSERT INTO emp VALUES(3,'DotNet');


select name from emp

SELECT DISTINCT(name) from emp


SELECT * FROM employee ORDER BY salary DESC  OFFSET 5

SELECT emp_id,dept_id 
FROM employee 
WHERE dept_id=(
	SELECT dept_id 
	FROM employee 
	WHERE emp_name='raja')



SELECT project_id,COUNT(emp_id) 
FROM allocation
GROUP BY project_id


SELECT project_id FROM allocation 
GROUP BY project_id
HAVING COUNT(emp_Id)>=ALL
	(SELECT COUNT(emp_id) 
	FROM allocation
	GROUP BY project_id)


select project_id,count(emp_id) from allocation
group by project_id
having count(emp_id)>= all(select count(emp_id) from allocation group by project_id)




