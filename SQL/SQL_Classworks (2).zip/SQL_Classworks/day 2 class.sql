﻿create table employee(empNo int,empName char(20),salary decimal(20), constraint empNo_pk primary key (empNo));

alter table employee add column deptId int;

alter table employee add constraint deptid_fk foreign key (deptId)

select * from employee
create table dept(deptId int, deptName char(20), constraint deptId_pk primary key (deptId));

insert into employee values(123,'gopi',123.00,10),(124,'gokul',123.99,12)


create table test( value1 int check(value1>0), value2 int check(value2>0))

select * from test
insert into test values(1,1)

drop table test


create table test( value1 int unique, value2 int not null)
insert into test(value2) values(3);


table level constraint
Check
unique
not null

operator
expression

where clause
update 
delete
like clause
limit
order by 
group by



