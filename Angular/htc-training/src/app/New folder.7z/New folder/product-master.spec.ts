import { ProductMaster } from './product-master';

describe('ProductMaster', () => {
  it('should create an instance', () => {
    expect(new ProductMaster()).toBeTruthy();
  });
});
