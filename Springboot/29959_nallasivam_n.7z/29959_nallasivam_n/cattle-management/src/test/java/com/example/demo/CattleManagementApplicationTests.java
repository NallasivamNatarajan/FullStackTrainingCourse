package com.example.demo;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CattleManagementApplicationTests {

}
